	<footer class="entry-footer">
		<?php ixion_entry_footer(); ?>
	</footer><!-- .entry-footer -->